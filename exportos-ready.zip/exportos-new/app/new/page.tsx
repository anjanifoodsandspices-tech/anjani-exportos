'use client'

import Link from 'next/link'
import { useState } from 'react'

export default function NewLead() {
  const [formData, setFormData] = useState({
    company: '',
    contact: '',
    email: '',
    phone: '',
    country: '',
  })

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    alert('✅ Lead created! (Demo mode - using mock data)')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="container py-4">
          <Link href="/" className="text-blue-600">← Back</Link>
          <h1 className="text-2xl font-bold mt-2">Create New Lead</h1>
        </div>
      </div>

      <div className="container max-w-xl">
        <div className="card mt-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Company *</label>
              <input type="text" className="input" required value={formData.company} onChange={(e) => setFormData({...formData, company: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Contact Person *</label>
              <input type="text" className="input" required value={formData.contact} onChange={(e) => setFormData({...formData, contact: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Email *</label>
              <input type="email" className="input" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Phone</label>
              <input type="tel" className="input" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Country *</label>
              <input type="text" className="input" required value={formData.country} onChange={(e) => setFormData({...formData, country: e.target.value})} />
            </div>
            <div className="flex gap-2">
              <button type="submit" className="btn btn-blue flex-1">Create Lead</button>
              <Link href="/" className="btn btn-gray flex-1 text-center">Cancel</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
