'use client'

import Link from 'next/link'

export default function LeadDetail({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="container py-4">
          <Link href="/" className="text-blue-600">← Back</Link>
          <h1 className="text-2xl font-bold mt-2">Lead #{params.id}</h1>
        </div>
      </div>

      <div className="container">
        <div className="card mt-8">
          <h2 className="text-xl font-bold mb-4">Lead Information</h2>
          <div className="grid grid-cols-2 gap-6">
            <div><p className="text-sm text-gray-600">Company</p><p className="font-medium">ABC Spices Ltd</p></div>
            <div><p className="text-sm text-gray-600">Contact</p><p className="font-medium">John Doe</p></div>
            <div><p className="text-sm text-gray-600">Email</p><p className="font-medium">john@abc.com</p></div>
            <div><p className="text-sm text-gray-600">Country</p><p className="font-medium">USA</p></div>
          </div>
        </div>
      </div>
    </div>
  )
}
