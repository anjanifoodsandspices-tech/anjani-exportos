'use client'

import { useState } from 'react'
import Link from 'next/link'

const mockLeads = [
  { id: 1, company: 'ABC Spices', contact: 'John Doe', email: 'john@abc.com', country: 'USA', status: 'new' },
  { id: 2, company: 'XYZ Foods', contact: 'Jane Smith', email: 'jane@xyz.com', country: 'UK', status: 'contacted' },
]

export default function Home() {
  const [leads, setLeads] = useState(mockLeads)
  const [search, setSearch] = useState('')

  const filtered = leads.filter(l => 
    l.company.toLowerCase().includes(search.toLowerCase()) ||
    l.email.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="container flex justify-between items-center py-4">
          <div>
            <h1 className="text-3xl font-bold">Anjani ExportOS</h1>
            <p className="text-gray-600">Export CRM Platform</p>
          </div>
          <div className="flex gap-2">
            <Link href="/new" className="btn btn-blue">+ New Lead</Link>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="grid grid-cols-4 gap-4 my-8">
          <div className="card"><div className="text-sm text-gray-600">Total Leads</div><div className="text-3xl font-bold text-blue-600">{leads.length}</div></div>
          <div className="card"><div className="text-sm text-gray-600">New</div><div className="text-3xl font-bold">{leads.filter(l => l.status === 'new').length}</div></div>
          <div className="card"><div className="text-sm text-gray-600">Contacted</div><div className="text-3xl font-bold text-yellow-600">{leads.filter(l => l.status === 'contacted').length}</div></div>
          <div className="card"><div className="text-sm text-gray-600">Won</div><div className="text-3xl font-bold text-green-600">{leads.filter(l => l.status === 'won').length}</div></div>
        </div>

        <div className="mb-6">
          <input type="text" placeholder="Search leads..." className="input" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        <div className="card overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Company</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Country</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(lead => (
                <tr key={lead.id}>
                  <td className="font-medium">{lead.company}</td>
                  <td>{lead.contact}</td>
                  <td className="text-sm">{lead.email}</td>
                  <td>{lead.country}</td>
                  <td><span className="px-2 py-1 rounded text-sm" style={{background: lead.status === 'new' ? '#dbeafe' : '#fef3c7'}}>{lead.status}</span></td>
                  <td><Link href={`/leads/${lead.id}`} className="text-blue-600">View</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
